## Sub-split of Flysystem for SFTP using phpseclib v3.

> ⚠️ this is a sub-split, for pull requests and issues, visit: https://github.com/thephpleague/flysystem

```bash
composer require league/flysystem-sftp-v3
```

View the [documentation](https://flysystem.thephpleague.com/docs/adapter/sftp-v3/).
